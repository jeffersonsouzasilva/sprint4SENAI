package com.mamuka.apimamuka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApimamukaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApimamukaApplication.class, args);
	}

}
