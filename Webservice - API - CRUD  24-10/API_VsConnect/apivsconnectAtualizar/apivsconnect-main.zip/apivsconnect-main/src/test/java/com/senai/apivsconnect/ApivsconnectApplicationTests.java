package com.senai.apivsconnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApivsconnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
